package com.myglass.app;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.os.Build;

public class NotificationService extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        String pack = sbn.getPackageName();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            RenderEffect blurEffect = RenderEffect.createBlurEffect(15f, 15f, Shader.TileMode.CLAMP);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
    }
}